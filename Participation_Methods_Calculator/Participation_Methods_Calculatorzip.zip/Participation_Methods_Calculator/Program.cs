﻿using System;

namespace Participation_Methods_Calculator
{
    class Program
    {
        static void Main(string[] args)
        {
            string name = "Mandar";
            string classname = "MIS3013";
            string date = "10/21/21";


            DeveloperInformation(name, classname, date);
         
        }

        static double Add(double val1 , double val2)
        {
            double sum = 0;
            sum = val1 + val2;
            return sum;
        }

        static double Subtract(double val1 , double val2)
        {
            double minus = 0;
            minus = val1 - val2;

            return minus;
        }
        static double Multiply(double val1 , double val2)
        {
            double Multi = 0;
            Multi = val1 * val2;

            return Multi;
        }
        static double Divide( double val1, double val2)
        {
            double div = 0;
            div = val1 / val2;

            return div;
        }
        static void DeveloperInformation( string name, string classname, string date)
        {
            Console.WriteLine($"The name of the developer is{name}");
            Console.WriteLine($" The class name of the developer is {classname}");
            Console.WriteLine($"The date the program wriiten is {date}");
        }
    }
}
